-- =========================================================
-- School Management System - Database Schema
-- =========================================================

-- Create database
CREATE DATABASE IF NOT EXISTS school_management
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE school_management;

-- =========================================================
-- Table: users
-- Stores login credentials for Admin, Teacher, Student
-- =========================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin','Teacher','Student') NOT NULL DEFAULT 'Student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =========================================================
-- Default Admin Account
-- Email:    admin@school.com
-- Password: Admin@123
--
-- The hash below was generated using PHP's password_hash()
-- function with the PASSWORD_DEFAULT (bcrypt) algorithm:
--     password_hash('Admin@123', PASSWORD_DEFAULT)
--
-- NOTE: Every time password_hash() runs it produces a different
-- (but equally valid) hash string because of the random salt.
-- The hash below is one valid example and password_verify()
-- will correctly validate 'Admin@123' against it.
-- =========================================================
INSERT INTO users (name, email, password, role)
VALUES (
    'Administrator',
    'admin@school.com',
    '$2b$10$i.l.YarfQgXp3Cm36xbV6.qDpotJZVOqRhwVckeJrm4UNrXwwwDE6',
    'Admin'
);

-- =========================================================
-- Optional: sample tables referenced on the dashboard
-- (students / teachers / classes counts). These are minimal
-- demo tables so the dashboard statistics have real data to
-- query. Extend these as your application grows.
-- =========================================================
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS teachers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS classes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Sample demo data so dashboard counters show something
INSERT INTO students (name) VALUES ('Aarav Sharma'), ('Priya Singh'), ('Rohan Gupta');
INSERT INTO teachers (name) VALUES ('Mrs. Kavita Rao'), ('Mr. Suresh Kumar');
INSERT INTO classes (class_name) VALUES ('Class 6-A'), ('Class 7-B'), ('Class 8-C');
